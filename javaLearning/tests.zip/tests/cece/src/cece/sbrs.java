package cece;

public class sbrs {
	public static void main(String [] args) {
		char[] array = new char [1];
		String b = "Blablidu";
		array = b.toCharArray();
		array[0] = 2;
		array[0] = 3;
		array[0] = '8';
		System.out.print(array[0]);
	}
}
