/**
 * 
 */
/**
 * 
 */
module cece {
	requires java.desktop;
}