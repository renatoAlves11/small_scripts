package P2_2022_1;

import java.util.HashSet;

public class LerArquivo {
	public static HashSet<String> retornaStrings(){
		HashSet<String> a = new HashSet<String>();
		a.add("235#Sol#1678.9");
		a.add("789#Lua#67.8#E");
		a.add("cdsbh");
		a.add("456#Jupiter#180#P");
		return a;
	}
}
