package P2_2018_2;

public class AlunoEspecial extends Aluno{
	public AlunoEspecial(String id) {
		super(id);
	}
}
