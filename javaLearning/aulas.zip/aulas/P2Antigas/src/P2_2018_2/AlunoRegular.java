package P2_2018_2;

public class AlunoRegular extends Aluno{
	public AlunoRegular(String id) {
		super(id);
	}
}
