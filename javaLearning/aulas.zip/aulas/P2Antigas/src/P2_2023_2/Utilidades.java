package P2_2023_2;

import java.util.Set;
import java.util.HashSet;

public class Utilidades {
	public static Set<String> getPalavroes(){
		Set<String> palavroes = new HashSet<String>();
		palavroes.add("puta");
		palavroes.add("arrombado");
		palavroes.add("cu");
		palavroes.add("pau");
		palavroes.add("cuzinho");
		palavroes.add("buceta");
		return palavroes;
	}
}
