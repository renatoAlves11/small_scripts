package PF_2023_1;

public class Escreve {
	 public Escreve() {
	 System.out.println("F");
	 }
	}
