package PF_2023_1;

public interface Corredor {
	void calcularVelocidade();
}
