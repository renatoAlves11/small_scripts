package PF_2023_1;

public class Carro implements Corredor{
	public void calcularVelocidade() {
		
	}
}
