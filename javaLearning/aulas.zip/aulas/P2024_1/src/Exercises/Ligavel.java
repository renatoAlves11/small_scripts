package Exercises;

public interface Ligavel {
	void ligavel();
}
