package Exercises;

public class Tapete extends Produto{
	public Tapete(String id) {
		super(id);
	}
}
