package ex1;

public class Programador extends Funcionario{
	public Programador(String id) {
		super(id);
	}
}
