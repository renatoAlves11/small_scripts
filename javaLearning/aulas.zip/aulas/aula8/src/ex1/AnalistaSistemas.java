package ex1;

public class AnalistaSistemas extends Funcionario{
	public AnalistaSistemas(String id) {
		super(id);
	}
	
}
