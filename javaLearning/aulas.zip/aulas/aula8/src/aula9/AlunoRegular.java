package aula9;

public class AlunoRegular extends Aluno{
	public AlunoRegular(String id) {
		super(id);
	}
}
