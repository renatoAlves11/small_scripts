package aula9;

public class AlunoEspecial extends Aluno{
	public AlunoEspecial(String id) {
		super(id);
	}
}